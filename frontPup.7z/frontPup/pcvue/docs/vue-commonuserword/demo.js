define([
    'require',
    'vue',
    'jQuery',
    'systemConfig',
    'vueCommonUseWord'
], function(require, Vue , $, systemConfig,commonwords) {
    'use strict';
    var main = new Vue({
        el:"#commonuserword",
        data:{
            mycomment: "123"
        },
        mounted:function(){
        },
        watch:{
        },
        methods:{
        },
    })
});