define([
    'require',
    'vue',
    'vueCigCheck'
], function (require, Vue, $) {
    'use strict';
    // 创建根实例
    new Vue({
        el: '#example',
        data: {
        },
        methods: {
        },
      })
});