define([
    'require',
    'vue'
], function(require, Vue) {
    'use strict';
    new Vue({
        el:"#other1"
    })
});