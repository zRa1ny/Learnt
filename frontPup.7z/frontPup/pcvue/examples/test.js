define([
    'require',
    'vue',
    'vueTable',
    'vueArea'
], function(require, Vue) {
    'use strict';
    new Vue({
        el:"#aaa",
        data:{
            aaa:{
                aaaaconfig:{checkbox:true}
            }
        }
    })
});